package com.bharath.springcloud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ProductserviceApplicationTests {

	@Test
	public void contextLoads() {
	}

}
